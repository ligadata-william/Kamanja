package com.ligadata.Controller

import java.io.File

import com.ligadata.AdaptersConfiguration.KafkaPartitionUniqueRecordValue
import com.ligadata.InputAdapters.KafkaSimpleConsumer
import com.ligadata.OnLEPBase._
import com.ligadata.ZooKeeper.{ZooKeeperListener, CreateClient}
import org.apache.curator.framework.CuratorFramework
import org.apache.log4j.Logger


import scala.io.Source
import org.json4s.jackson.JsonMethods._
import scala.sys.process.{ProcessIO, Process}

object SimpleStats extends CountersAdapter {

  override def addCntr(key: String, cnt: Long): Long = 0
  override def addCntr(cntrs: scala.collection.immutable.Map[String, Long]): Unit = {}
  override def getCntr(key: String): Long = 0
  override def getDispString(delim: String): String = ""
  override def copyMap: scala.collection.immutable.Map[String, Long] = null
}

object OnLEPMonitorConfig {
  var modelsData: List[Map[String, Any]] = null
}

object MakeExecContextImpl extends MakeExecContext {
  def CreateExecContext(input: InputAdapter, curPartitionId: Int, output: Array[OutputAdapter], envCtxt: EnvContext): ExecContext = {
    new ExecContextImpl(input, curPartitionId, output, envCtxt)
  }
}

// There are no locks at this moment. Make sure we don't call this with multiple threads for same object
class ExecContextImpl(val input: InputAdapter, val curPartitionId: Int, val output: Array[OutputAdapter], val envCtxt: EnvContext) extends ExecContext {
  val agg = SampleAggregator.getNewSampleAggregator
  initializeModelsToMonitor(OnLEPMonitorConfig.modelsData,agg)
  agg.setIsLookingForSeed(true)

  private def initializeModelsToMonitor(modelsToMonitorInfo: List[Map[String,Any]], agg: SampleAggregator): Unit = {
    modelsToMonitorInfo.foreach(model => {
      val mName = model("name").asInstanceOf[String]
      agg.addModelToMonitor(mName)

      val keys = model("keys").asInstanceOf[List[String]]
      agg.addAggregationKey(mName,keys)

      val valCombos = model("displayValues").asInstanceOf[List[Map[String,List[String]]]]
      valCombos.foreach(value => {
        val dvals = value("values").asInstanceOf[List[String]]
        agg.addValueCombination(mName,dvals)
      })
    })

  }

  def execute(tempTransId: Long, data: String, format: String, uniqueKey: PartitionUniqueRecordKey, uniqueVal: PartitionUniqueRecordValue, readTmNanoSecs: Long, readTmMilliSecs: Long, ignoreOutput: Boolean, processingXformMsg: Int, totalXformMsg: Int): Unit = {

    if (format.equalsIgnoreCase("json")) {
    //if (data.charAt(0).toString.equals("{")) {
      agg.processJsonMessage(parse(data).values.asInstanceOf[Map[String,Any]])
    } else {
      agg.processCSVMessage(data,uniqueVal.asInstanceOf[KafkaPartitionUniqueRecordValue].Offset)
    }
  }
}

class OnLEPMonitor  {
  private val LOG = Logger.getLogger(getClass)
  type OptionMap = Map[Symbol, Any]
  var isStarted: Boolean = false
  var zkNodeBasePath:String = null
  var zkConnectString:String = null
  var dataLoadCommand:String = null
  var zkDataPath:String = null
  var zkActionPath:String = null
  var seed: Long = 0
  var prc: Process = null

  val conf = new AdapterConfiguration
  val s_conf = new AdapterConfiguration
  var adapter: InputAdapter = _
  var s_adapter: InputAdapter = _

  var oAdaptersConfigs: List[AdapterConfiguration] = List[AdapterConfiguration]()
  var oAdapters: List[InputAdapter] = List[InputAdapter]()
  var sAdaptersConfigs: List[AdapterConfiguration] = List[AdapterConfiguration]()
  var sAdapters: List[InputAdapter] = List[InputAdapter]()

  /**
   * ActionOnActionChange - This method will get called when the /ligadata/monitor/action value in zookeeper is changed.
   *                        this method is passed as a callback into a zookeeper listener implementation.
   * @param receivedString String
   */
  private def ActionOnActionChange(receivedString: String): Unit = {
    if (receivedString.size == 1 && receivedString.toInt == 1) {
      LOG.info("Monitoring turned ON")
      if (isStarted) {
        return
      }

      // Start all the neede Kafka Adapters for Output queues
      oAdaptersConfigs.foreach(conf => {
        // Create Kafka Consumer Here for the output queue
        val t_adapter = KafkaSimpleConsumer.CreateInputAdapter(conf, null, null, MakeExecContextImpl, SimpleStats)
        val t_adapterMeta: Array[(PartitionUniqueRecordKey, PartitionUniqueRecordValue)] = t_adapter.getAllPartitionEndValues

        //  Initialize and start the adapter that is going to read the output queues here.
        val inputMeta = t_adapterMeta.map(partMeta => {
          val elem: (PartitionUniqueRecordKey, PartitionUniqueRecordValue, Long, (PartitionUniqueRecordValue, Int, Int)) = (partMeta._1, partMeta._2, 0, (partMeta._2, 0, 0))
          elem
        }).toArray
        t_adapter.StartProcessing(t_adapterMeta.size, inputMeta, false)
        oAdapters = oAdapters ::: List(t_adapter)
      })

      // Initialize and start the adapter that is going to read the status queue here.  - there is onlly 1 of these for now.
      var sub: Boolean = false
      s_adapter = KafkaSimpleConsumer.CreateInputAdapter(sAdaptersConfigs.head, null, null, MakeExecContextImpl, SimpleStats)
      val s_adapterMeta: Array[(PartitionUniqueRecordKey, PartitionUniqueRecordValue)] = s_adapter.getAllPartitionEndValues
      val s_inputMeta = s_adapterMeta.map(partMeta => {
        if (!sub) {
          partMeta._2.asInstanceOf[KafkaPartitionUniqueRecordValue].Offset = partMeta._2.asInstanceOf[KafkaPartitionUniqueRecordValue].Offset - 1
          SampleAggregator.setTT(partMeta._2.asInstanceOf[KafkaPartitionUniqueRecordValue].Offset)
          sub = true
        }
        val elem: (PartitionUniqueRecordKey, PartitionUniqueRecordValue, Long, (PartitionUniqueRecordValue, Int, Int)) = (partMeta._1, partMeta._2, 0, (partMeta._2, 0, 0))
        elem
      }).toArray
      s_adapter.StartProcessing(s_adapterMeta.size, s_inputMeta, false)
      sAdapters = sAdapters ::: List(s_adapter)

      // The adapters have been scheduled to run.. data will be coming in and aggregated  asynchrinously..  Flip the switch to externalize the collected
      // data to zookeeper (or another destination when we allow for it)
      isStarted = true

      // If it is required start loading input data into the OnLEP engine by executing a separate script.
      // for example: "java -jar /mnt/d3/demo_20150115/engine/SimpleKafkaProducer-0.1.0 --gz true --topics \"testin_1\" --threads 1 --topicpartitions 8 --brokerlist \"localhost:9092\" --files \"/mnt/d3/demo_20150115/demodata/msgdata/copdv1_eval_combined_25000.csv.gz\" --partitionkeyidxs \"1\"  --sleep 10 --format CSV"
      if (dataLoadCommand != null) {
        val pb = Process(dataLoadCommand)
        val pio = new ProcessIO(_ => (),
                                stdout => scala.io.Source.fromInputStream(stdout).getLines.foreach(LOG.info),
                                err => {scala.io.Source.fromInputStream(err).getLines.foreach(LOG.error)})

        prc = pb.run(pio)
      }
    } else {
      LOG.info("Monitoring turned OFF")
      isStarted = false

      // clean up monitor resources here.
      if (prc != null) {
	      prc.destroy()
        prc = null
	    }

      if (sAdapters.size > 0) {
        sAdapters.map(adapter => {adapter.Shutdown})
        sAdapters = List[InputAdapter]()
      }

      if (oAdapters.size > 0) {
        oAdapters.map(adapter => {adapter.Shutdown})
        oAdapters = List[InputAdapter]()
      }

      SampleAggregator.reset
    }
  }

  /**
   * start - start monitoring the objects described in the parameter file.  This method will terminate when a user
   *         turns off the appropriate flag in the zookeeper.
   */
  def start(inParms: Array[String]): Unit = {

    // Parse the input.
    val options = nextOption(Map(), inParms.toList)

    // Validate and set flags based on the input
    val parmFile = options.getOrElse('parm, null).asInstanceOf[String]
    if (parmFile == null) {
      LOG.error("Need input files as parameter")
      return
    }

    // Get the output
    val jsonparms = parse(Source.fromFile(parmFile).getLines.mkString).values.asInstanceOf[Map[String, Any]]

    // Get the ZooKeeper info and preform the zookeeper initialization
    val zkInfo = jsonparms.getOrElse("ZookeeperInfo", null).asInstanceOf[Map[String, String]]
    if (zkInfo == null) {
      LOG.error("ERROR: missing Zookeeper info")
      return
    }
    zkNodeBasePath = zkInfo.getOrElse("ZooKeeperNodeBasePath", null)
    zkConnectString = zkInfo.getOrElse("ZooKeeperConnectString", null)
    dataLoadCommand = jsonparms.getOrElse("inputProcessString",null).toString

    val zkUpdateFreq = zkInfo.getOrElse("ZooKeeperUpdateFrequency",null)
    if (zkUpdateFreq == null ) {
      LOG.error("ERROR: Invalid Freq")
      return
    }

    if (zkNodeBasePath == null || zkConnectString == null) {
      LOG.error("ERROR: Missing Zookeeper BASE PATH or CONNECT STRING parameter")
      return
    }

    // base paths
    zkActionPath = zkNodeBasePath + "/monitor/action"
    zkDataPath = zkNodeBasePath + "/monitor/data"

    // Just in case this is the first time to this zk instance.
    CreateClient.CreateNodeIfNotExists(zkConnectString, zkActionPath)
    val zcf: CuratorFramework = CreateClient.createSimple(zkConnectString)

    // Read the kafka queue informations
    val kafkaInfo = jsonparms.getOrElse("KafkaInfo",null).asInstanceOf[Map[String,List[Any]]]
    if (kafkaInfo == null) {
      LOG.warn("WARN: NOTHING TO MONITOR - No kafka sources specified")
      return
    }

    // configure kafka adapters configs
    configureKafkaAdapters(kafkaInfo)

    // Read the section that tells us which models to monitor and how.
    val modelsToMonitorInfo = jsonparms.getOrElse("ModelsToMonitor", null).asInstanceOf[Map[String, List[Any]]]

    if (modelsToMonitorInfo == null) {
      LOG.warn("WARN: NOTHING TO MONITOR - Models to monitor info is missing")
      return
    }

    // each model instance is an array.
    val modelsData = modelsToMonitorInfo.getOrElse("Models", null).asInstanceOf[List[Map[String, Any]]]

    if (modelsData == null) {
      LOG.warn("WARN: NOTHING TO MONITOR  - no models specified")
      return
    }
    OnLEPMonitorConfig.modelsData = modelsData


    // Establish a listener for the action field.  If that value changes, "ActinOnActionChange" callback function will be
    // called.
    val zkMonitorListener = new ZooKeeperListener
    zkMonitorListener.CreateListener(zkConnectString, zkActionPath, ActionOnActionChange, 3000, 3000)

    // Loop until its time to externalize data.
    while (true) {
      Thread.sleep(zkUpdateFreq.toInt)
      if (isStarted) {
        SampleAggregator.externalizeExistingData(zkConnectString, zkNodeBasePath, seed)
      }
    }

    // in case of stuff hitting the fan, free up the prc
    if (prc != null) {
      prc.destroy()
    }
    return;
  }

  /**
   * configureKafkaAdapters - set up the oAdapters and sAdapter arrays here.
   * @param aConfigs  Map[String,List[Any]]
   */
  private def configureKafkaAdapters(aConfigs: Map[String,List[Any]]): Unit = {
    val statusQs: List[Map[String,Any]] = aConfigs.getOrElse("StatusQs",null).asInstanceOf[List[Map[String,Any]]]
    val outputQs: List[Map[String,Any]] = aConfigs.getOrElse("OutputQs",null).asInstanceOf[List[Map[String,Any]]]

    // Process all the status kafka Qs here
    if (statusQs != null) {
      statusQs.foreach(qConf => {
        val thisConf: AdapterConfiguration = new AdapterConfiguration
        thisConf.Name = qConf.getOrElse("Name","").toString
        thisConf.formatOrInputAdapterName = qConf.getOrElse("Format","").toString
        thisConf.className = qConf.getOrElse("ClassName","").toString
        thisConf.jarName = qConf.getOrElse("JarName","").toString
        thisConf.dependencyJars = qConf.getOrElse("DependencyJars","").asInstanceOf[List[String]].toSet
        thisConf.adapterSpecificCfg = qConf.getOrElse("AdapterSpecificCfg","").toString

        // Ignore if any value in the adapter was not set.
        if (thisConf.Name.size > 0 &&
            thisConf.formatOrInputAdapterName.size > 0 &&
            thisConf.className.size > 0 &&
            thisConf.jarName.size > 0 &&
            thisConf.dependencyJars.size > 0 &&
            thisConf.dependencyJars.size > 0) {
          sAdaptersConfigs = sAdaptersConfigs ::: List[AdapterConfiguration](thisConf)
        }
      })
    }

    // Process all the output Kafka Qs
    if (outputQs != null) {
      outputQs.foreach(qConf => {
        val thisConf: AdapterConfiguration = new AdapterConfiguration
        thisConf.Name = qConf.getOrElse("Name","").toString
        thisConf.formatOrInputAdapterName = qConf.getOrElse("Format","").toString
        thisConf.className = qConf.getOrElse("ClassName","").toString
        thisConf.jarName = qConf.getOrElse("JarName","").toString
        thisConf.dependencyJars = qConf.getOrElse("DependencyJars","").asInstanceOf[List[String]].toSet
        thisConf.adapterSpecificCfg = qConf.getOrElse("AdapterSpecificCfg","").toString

        // Ignore if any value in the adapter was not set.
        if (thisConf.Name.size > 0 &&
            thisConf.formatOrInputAdapterName.size > 0 &&
            thisConf.className.size > 0 &&
            thisConf.jarName.size > 0 &&
            thisConf.dependencyJars.size > 0 &&
            thisConf.dependencyJars.size > 0) {
          oAdaptersConfigs = oAdaptersConfigs ::: List[AdapterConfiguration](thisConf)
        }
      })
    }
  }

  /*
  * nextOption - parsing input options
   */
  private def nextOption(map: OptionMap, list: List[String]): OptionMap = {
    def isSwitch(s: String) = (s(0) == '-')
    list match {
      case Nil => map
      case "--parm" :: value :: tail =>
        nextOption(map ++ Map('parm -> value), tail)
      case option :: tail => {
        LOG.error("Unknown option " + option)
        sys.exit(1)
      }
    }
  }
}


/**
 * Created by dan on 1/9/15.
 */
object Monitor {
  def main (args: Array[String]): Unit = {

    val monitor: OnLEPMonitor = new OnLEPMonitor()
    monitor.start(args)

  }
}
