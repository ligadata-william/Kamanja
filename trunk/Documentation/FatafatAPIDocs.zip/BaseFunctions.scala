package com.ligadata.BaseFunctions

object AndOp{
  def and(val1: Boolean, val2: Boolean): Boolean = val1 && val2
}

object OrOp{
  def or(val1: Boolean, val2: Boolean): Boolean = val1 || val2
}

